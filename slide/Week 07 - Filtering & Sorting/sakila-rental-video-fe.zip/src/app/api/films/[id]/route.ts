import { NextResponse } from 'next/server';

const BACKEND_URL = process.env.BACKEND_URL || process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000';

export async function GET(_req: Request, context: { params: { id: string } }) {
  try {
    const { id } = context.params || ({} as any);
    if (!id) {
      return NextResponse.json({ message: 'Missing film id' }, { status: 400 });
    }

    const url = `${BACKEND_URL.replace(/\/$/, '')}/films/${encodeURIComponent(id)}`;

    const res = await fetch(url, {
      cache: 'no-store',
      // Do not forward cookies/credentials to avoid CORS/auth issues unless needed
      // credentials: 'include',
      // headers: { ... }, // add if backend requires
    });

    const contentType = res.headers.get('content-type') || '';
    if (!res.ok) {
      // Try to proxy error body when possible
      const body = contentType.includes('application/json') ? await res.json() : await res.text();
      return NextResponse.json(
        { message: 'Upstream error', status: res.status, body },
        { status: res.status }
      );
    }

    if (contentType.includes('application/json')) {
      const data = await res.json();
      return NextResponse.json(data, { status: 200 });
    }

    // Fallback: return as text
    const text = await res.text();
    return new NextResponse(text, {
      status: 200,
      headers: { 'content-type': contentType || 'application/json; charset=utf-8' },
    });
  } catch (e: any) {
    return NextResponse.json({ message: e?.message || 'Proxy request failed' }, { status: 502 });
  }
}
