'use client';

// components/Pagination.tsx

import { useRouter } from 'next/navigation';

interface PaginationProps {
    currentPage: number;
    totalPages: number;
    thePath: string;
    pageSize: number;
    filmTitle: string;
    filmRating?: string[];
    sortBy?: string;
}

export default function Pagination({ currentPage, pageSize, totalPages, thePath, filmTitle, filmRating = [] }: PaginationProps) {
    const router = useRouter();

    const goToPage = (page: number) => {
        // Preserve pageSize and other filters
        const qs = new URLSearchParams({ page: String(page), pageSize: String(pageSize) });
        if (filmTitle) qs.set('filmTitle', filmTitle);
        if (filmRating && filmRating.length) {
            filmRating.forEach((r) => qs.append('filmRating', r));
        }
        router.push(`${thePath}?${qs.toString()}`);
    };

    const getPageNumbers = () => {
        const pages: (number | string)[] = [];

        if (totalPages <= 12) {
            for (let i = 1; i <= totalPages; i++) pages.push(i);
        } else {
            pages.push(1);

            if (currentPage > 3) {
                pages.push('...');
            }

            var start = Math.max(2, currentPage-2);
            const end = Math.min(totalPages-1, currentPage + 10);
            if(currentPage > totalPages - 10) start = totalPages - 12;
            for (let i = start; i <= end; i++) {
                pages.push(i);
            }

            if (currentPage < totalPages - 2) {
                pages.push('...');
            }

            pages.push(totalPages);
        }
        return pages;
    };

    return (
        <nav className="flex items-center justify-center mt-6 space-x-2">
            {/* Prev button */}
            {currentPage > 1 && (
                <button
                    onClick={() => goToPage(currentPage - 1)}
                    className="px-3 py-1 rounded-md border text-sm hover:bg-gray-200"
                >
                    Prev
                </button>
            )}

            {/* Page numbers */}
            {getPageNumbers().map((page, i) => (
                typeof page === 'number' ? (
                    <button
                        key={i}
                        onClick={() => goToPage(page)}
                        className={`px-3 py-1 rounded-md border text-sm ${
                            page === currentPage ? 'bg-blue-500 text-white' : 'hover:bg-gray-200'
                        }`}
                    >
                        {page}
                    </button>
                ) : (
                    <span key={i} className="px-2 text-gray-500">
                        {page}
                    </span>
                )
            ))}

            {/* Next button */}
            {currentPage < totalPages && (
                <button
                    onClick={() => goToPage(currentPage + 1)}
                    className="px-3 py-1 rounded-md border text-sm hover:bg-gray-200"
                >
                    Next
                </button>
            )}
        </nav>
    );
}