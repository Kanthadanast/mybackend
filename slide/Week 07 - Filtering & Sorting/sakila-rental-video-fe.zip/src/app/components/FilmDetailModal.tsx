"use client";

import {useEffect, useState} from "react";

interface Actor {
    id: number,
    name: string
}

interface FilmDetail {
    id: number;
    title: string;
    rating?: number | string;
    releaseYear?: number;
    description?: string;
    length?: number;
    language?: string;
    specialFeatures?: string;
    actors?: Actor[];
}

interface FilmDetailModalProps {
    filmId: number | null;
    onClose: () => void;
}

const API_ORIGIN = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000';
const BASE_URL = `${API_ORIGIN}/films`;

export default function FilmDetailModal({filmId, onClose}: FilmDetailModalProps) {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [film, setFilm] = useState<FilmDetail | null>(null);

    useEffect(() => {
        if (!filmId) return;

        let cancelled = false;
        const controller = new AbortController();

        async function load() {
            setLoading(true);
            setError(null);
            setFilm(null);

            try {
                // Prefer explicit public API origin; fall back to same-origin in browser to avoid CORS during local dev
                const origin = process.env.NEXT_PUBLIC_API_URL || (typeof window !== 'undefined' ? window.location.origin : '');
                const url = `${BASE_URL}/${filmId}`;
                const res = await fetch(url, {signal: controller.signal, cache: 'no-store'});
                if (!res.ok) {
                    throw new Error(`Request failed with status ${res.status}`);
                }
                const data = await res.json();
                // alert(JSON.stringify(data));
                if (!cancelled) {
                    setFilm(data);
                    setLoading(false);
                }
            } catch (e: any) {
                if (controller.signal.aborted) return;
                if (!cancelled) {
                    setError(e?.message || 'Failed to fetch film details');
                    setLoading(false);
                }
            }
        }

        load();

        return () => {
            cancelled = true;
            controller.abort();
        };
    }, [filmId]);

    if (!filmId) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
            {/* Backdrop */}
            <button
                aria-label="Close modal"
                onClick={onClose}
                className="absolute inset-0 bg-black/50"
            />

            {/* Dialog */}
            <div
                className="relative mx-4 max-h-[85vh] w-full max-w-2xl overflow-auto rounded-lg bg-white p-4 shadow-xl">
                <button
                    onClick={onClose}
                    className="absolute right-3 top-3 rounded px-2 py-1 text-sm text-gray-600 hover:bg-gray-100"
                >
                    ✕
                </button>

                {loading && (
                    <div className="p-6 text-center text-gray-600">Loading…</div>
                )}
                {error && (
                    <div className="p-6 text-center text-red-600">{error}</div>
                )}
                {!loading && !error && film && (
                    <div>
                        <h2 className="mb-2 text-2xl font-bold">{film.title}</h2>
                        <div className="space-y-1 text-sm text-gray-700">
                            {film.description !== undefined && (
                                <div><b>Special Features:</b> <span className="font-medium">{film.specialFeatures}</span></div>
                            )}
                            {film.rating !== undefined && (
                                <div><b>Rating:</b> <span className="font-medium">{film.rating}</span></div>
                            )}
                            {film.releaseYear !== undefined && (
                                <div><b>Release</b> year: <span className="font-medium">{film.releaseYear}</span></div>
                            )}
                            {film.description !== undefined && (
                                <div><b>Length:</b> <span className="font-medium">{film.length} min</span></div>
                            )}
                            {film.language && (
                                <div><b>Language:</b> <span className="font-medium">{film.language}</span></div>
                            )}
                        </div>

                        {film.description && (
                            <p className="mt-4 whitespace-pre-line">
                                <strong>Description:<br/></strong>{film.description}</p>
                        )}
                        <strong>Actors:</strong><br/>
                        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-1">
                            {film?.actors?.map((actor) => (
                                <button className="flex flex-col gap-1 items-start border rounded p-0
                                text-left border-cyan-950" key={actor.id}>
                                    <span className="ml-2">{actor.name}</span>
                                </button>
                            ))}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}
