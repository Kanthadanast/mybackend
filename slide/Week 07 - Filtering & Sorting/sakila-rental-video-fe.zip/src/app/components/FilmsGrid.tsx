'use client';

import { useState } from 'react';
import FilmDetailModal from '@/app/components/FilmDetailModal';

export interface FilmItem {
  id: number;
  title: string;
  rating: number | string;
  releaseYear: number;
}

interface FilmsGridProps {
  films: FilmItem[];
}

export default function FilmsGrid({ films }: FilmsGridProps) {
  const [selectedId, setSelectedId] = useState<number | null>(null);

  const openModal = (id: number) => setSelectedId(id);
  const closeModal = () => setSelectedId(null);

  return (
    <>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-0">
        {films?.map((film) => (
          <button
            key={film.id}
            onClick={() => openModal(film.id)}
            className="border rounded p-2 bg-white/50 dark:bg-black/20 shadow-sm block text-left hover:shadow-md transition focus:outline-none focus:ring-2 focus:ring-blue-400"
          >
            <div className="font-semibold text-lg text-blue-600 hover:underline">{film.title}</div>
            <div className="text-sm text-gray-600">Rating: {film.rating}</div>
            <div className="text-sm text-gray-600">Release: {film.releaseYear}</div>
          </button>
        ))}
        {!films?.length && (
          <div className="col-span-full text-gray-500">No films found.</div>
        )}
      </div>

      {selectedId !== null && (
        <FilmDetailModal filmId={selectedId} onClose={closeModal} />
      )}
    </>
  );
}
