import Pagination from "@/app/components/Pagination";
import FilmsGrid from "@/app/components/FilmsGrid";

// Prefer configurable API origin; default to local backend on 3000
const API_ORIGIN = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000';
const BASE_URL = `${API_ORIGIN}/films`;

interface Film {
    id: number;
    title: string;
    rating: number | string;
    releaseYear: number;
}

// Valid ratings list for filtering UI and validation
const RATINGS = ["G", "PG", "PG_13", "R", "NC_17"] as const;

type Rating = typeof RATINGS[number];

export default async function FilmsPage({
                                            searchParams,
                                        }: {
    // accept any shape at runtime; Next.js may provide string | string[]
    searchParams?: Promise<Record<string, any>>;
}) {
    const params = (await searchParams) || {};
    const pageRaw: string | undefined = params.page as string | undefined;
    const pageSizeRaw: string | undefined = params.pageSize as string | undefined;
    const qRaw: string | undefined = params.filmTitle as string | undefined;
    const sortByRaw: string | undefined = params.sortBy as string | undefined;

    // Gather filmRating from query: supports repeated params and comma-separated
    const frRaw = params.filmRating as string | string[] | undefined;
    let selectedRatings: Rating[] = [];
    if (Array.isArray(frRaw)) {
        selectedRatings = frRaw.filter((r): r is Rating => RATINGS.includes(r as Rating));
    } else if (typeof frRaw === 'string' && frRaw.trim()) {
        selectedRatings = frRaw
            .split(',')
            .map((s) => s.trim())
            .filter((r): r is Rating => RATINGS.includes(r as Rating));
    }

    const page = Number.parseInt(pageRaw ?? '1') || 1;
    const pageSize = Number.parseInt(pageSizeRaw ?? '12') || 12;
    const q = (qRaw ?? '').trim();

    const url = new URL(BASE_URL);
    url.searchParams.set('page', String(page));
    url.searchParams.set('pageSize', String(pageSize));
    if (q) {
        url.searchParams.set('filmTitle', q);
    }
    if (sortByRaw) {
        url.searchParams.set('sortBy', sortByRaw);
    }
    // Append selected ratings to API request
    selectedRatings.forEach((r) => url.searchParams.append('filmRating', r));

    let payload: { data: Film[]; totalPages: number } = {data: [], totalPages: 1};
    try {
        const res = await fetch(url.toString(), {cache: 'no-store'});
        if (res.ok) {
            payload = await res.json();
        }
    } catch (e) {
        // swallow network error and render empty state
    }

    const films = payload;

    return (
        <div className="pt-6 pl-6 max-w-6xl mx-auto">
            <h1 className="text-2xl font-bold mb-4">Films</h1>

            {/* Search and Filters */}
            <form action="/films" method="get" className="mb-4 flex flex-col gap-3">
                <div className="flex items-center gap-2 flex-wrap">
                    <input
                        type="search"
                        name="filmTitle"
                        defaultValue={q}
                        placeholder="Search films title ..."
                        className="w-full max-w-md rounded-md border border-gray-300 bg-white px-3 py-2 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                    />
                    {/* Reset to first page on new search, keep current pageSize */}
                    <input type="hidden" name="page" value="1"/>
                    <input type="hidden" name="pageSize" value={String(pageSize)}/>
                    <button
                        type="submit"
                        className="rounded-md bg-blue-600 px-2 py-1 text-sm font-medium text-white hover:bg-blue-700"
                    >
                        Search
                    </button>
                    {q || selectedRatings.length ? (
                        <a
                            href="/films"
                            className="rounded-md border border-gray-300 px-2 py-1 text-sm text-gray-700 hover:bg-gray-50"
                        >
                            Clear
                        </a>
                    ) : null}
                </div>
                {/* Ratings checkboxes */}
                <fieldset className="w-full">
                    <div className="mt-2 flex flex-wrap items-center gap-4 mr-2">
                        <div className="flex items-center gap-4 border-2 border-gray-300 rounded-md p-2">
                            <legend className="text-md font-medium text-red-800">Rating:</legend>
                            {RATINGS.map((r) => (
                                <label key={r} className="inline-flex items-center gap-2 text-sm">
                                    <input
                                        type="checkbox"
                                        name="filmRating"
                                        value={r}
                                        defaultChecked={selectedRatings.includes(r)}
                                        className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                                    />
                                    <span>{r}</span>
                                </label>
                            ))}
                        </div>
                        <div className="flex items-center gap-2 ml-2 border-2 border-gray-300 rounded-md px-4">
                            <label htmlFor="sortBy" className="text-md font-medium text-red-800">Sort by:</label>
                            <select
                                id="sortBy"
                                name="sortBy"
                                defaultValue={sortByRaw || ''}
                                className="rounded-md border border-gray-300 bg-white px-3 py-2 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                            >
                                <option value="">Default</option>
                                <option value="title:desc">Title Z-A</option>
                                <option value="release_year:desc">Release Year</option>
                                <option value="rating">Rating</option>
                            </select>
                        </div>
                    </div>
                </fieldset>
            </form>

            <FilmsGrid films={films?.data || []}/>
            <div className="mt-6">
                <Pagination
                    currentPage={page}
                    pageSize={pageSize}
                    totalPages={films.totalPages || 1}
                    thePath="/films"
                    filmTitle={q}
                    filmRating={selectedRatings}
                    sortBy={sortByRaw}
                />
            </div>
        </div>
    );
}