(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_c8f11e58._.js",
  "static/chunks/2d509_next_dist_compiled_react-dom_fca19625._.js",
  "static/chunks/2d509_next_dist_compiled_next-devtools_index_b150465e.js",
  "static/chunks/2d509_next_dist_compiled_1cf54f51._.js",
  "static/chunks/2d509_next_dist_client_8008ec66._.js",
  "static/chunks/2d509_next_dist_84f377b7._.js",
  "static/chunks/2d509_@swc_helpers_cjs_712074a7._.js"
],
    source: "entry"
});
