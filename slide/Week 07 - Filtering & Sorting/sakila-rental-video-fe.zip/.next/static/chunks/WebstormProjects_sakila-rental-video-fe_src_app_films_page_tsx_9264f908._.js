(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/WebstormProjects_sakila-rental-video-fe_96151b8b._.js"
],
    source: "dynamic"
});
